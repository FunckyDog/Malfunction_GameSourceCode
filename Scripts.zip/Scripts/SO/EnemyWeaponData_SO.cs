using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "New Enemy Weapon Data", menuName = "Data/Enemy Weapon Data")]
public class EnemyWeaponData_SO : WeaponData_SO
{
    public float shootRate;
}
