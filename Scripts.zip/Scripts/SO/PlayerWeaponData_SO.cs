using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "New Player Weapon Data", menuName = "Data/Player Weapon Data")]
public class PlayerWeaponData_SO : WeaponData_SO
{
    public AttributeData_SO shootRate;
}
